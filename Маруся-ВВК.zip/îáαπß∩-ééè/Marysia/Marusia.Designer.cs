﻿namespace Marysia
{
    partial class Marusia
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Marusia));
            this.Marysia = new System.Windows.Forms.Button();
            this.Frazis = new System.Windows.Forms.Label();
            this.marusiaDataSet = new Marysia.MarusiaDataSet();
            this.testBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testTableAdapter = new Marysia.MarusiaDataSetTableAdapters.testTableAdapter();
            this.tableAdapterManager = new Marysia.MarusiaDataSetTableAdapters.TableAdapterManager();
            this.col1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.marusiaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Marysia
            // 
            this.Marysia.BackColor = System.Drawing.Color.Transparent;
            this.Marysia.BackgroundImage = global::Marysia.Properties.Resources.logo_02_1;
            this.Marysia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Marysia.FlatAppearance.BorderSize = 0;
            this.Marysia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Marysia.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Marysia.Location = new System.Drawing.Point(343, 261);
            this.Marysia.Name = "Marysia";
            this.Marysia.Size = new System.Drawing.Size(119, 131);
            this.Marysia.TabIndex = 2;
            this.Marysia.UseVisualStyleBackColor = false;
            this.Marysia.Click += new System.EventHandler(this.Marysia_Click);
            // 
            // Frazis
            // 
            this.Frazis.AutoSize = true;
            this.Frazis.BackColor = System.Drawing.Color.Transparent;
            this.Frazis.Font = new System.Drawing.Font("Comic Sans MS", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Frazis.Location = new System.Drawing.Point(343, 46);
            this.Frazis.Name = "Frazis";
            this.Frazis.Size = new System.Drawing.Size(117, 46);
            this.Frazis.TabIndex = 3;
            this.Frazis.Text = "Фразы";
            // 
            // marusiaDataSet
            // 
            this.marusiaDataSet.DataSetName = "MarusiaDataSet";
            this.marusiaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testBindingSource
            // 
            this.testBindingSource.DataMember = "test";
            this.testBindingSource.DataSource = this.marusiaDataSet;
            // 
            // testTableAdapter
            // 
            this.testTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.testTableAdapter = this.testTableAdapter;
            // 
            // col1
            // 
            this.col1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.testBindingSource, "col1", true));
            this.col1.DataSource = this.testBindingSource;
            this.col1.DisplayMember = "col1";
            this.col1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.col1.FormattingEnabled = true;
            this.col1.Location = new System.Drawing.Point(56, 161);
            this.col1.Name = "col1";
            this.col1.Size = new System.Drawing.Size(702, 36);
            this.col1.TabIndex = 4;
            this.col1.ValueMember = "col1";
            // 
            // Marusia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.col1);
            this.Controls.Add(this.Frazis);
            this.Controls.Add(this.Marysia);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Marusia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Маруся";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.marusiaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Marysia;
        private System.Windows.Forms.Label Frazis;
        private MarusiaDataSet marusiaDataSet;
        private System.Windows.Forms.BindingSource testBindingSource;
        private MarusiaDataSetTableAdapters.testTableAdapter testTableAdapter;
        private MarusiaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox col1;
    }
}

