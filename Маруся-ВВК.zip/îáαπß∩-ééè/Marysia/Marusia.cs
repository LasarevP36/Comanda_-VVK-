﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Marysia
{
    public partial class Marusia : Form
    {
        public Marusia()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "marusiaDataSet.test". При необходимости она может быть перемещена или удалена.
            this.testTableAdapter.Fill(this.marusiaDataSet.test);
            

        }
        private void testBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.testBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.marusiaDataSet);

        }

        private void Marysia_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-P18NV1T\SQLEXPRESS;Initial Catalog=Marusia;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter(@"Select * from test where col1 like '" + col1.Text.Trim() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["Peremenniy"].ToString() == "0")
                    {
                        MessageBox.Show("Фраза для Марусе");
                    }

                    else if (dt.Rows[i]["Peremenniy"].ToString() == "1")
                        MessageBox.Show("Фраза не относится к Марусе");
                }
            }
        }

       
    }
}